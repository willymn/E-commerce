-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 15, 2023 at 12:54 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `queensdb`
--
CREATE DATABASE IF NOT EXISTS `queensdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `queensdb`;

-- --------------------------------------------------------

--
-- Table structure for table `cart_item`
--

CREATE TABLE IF NOT EXISTS `cart_item` (
  `cartID` int(11) NOT NULL AUTO_INCREMENT,
  `prodID` int(11) NOT NULL,
  `orderID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`cartID`),
  KEY `prodID` (`prodID`),
  KEY `orderID` (`orderID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `categoryID` int(11) NOT NULL AUTO_INCREMENT,
  `subID` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  PRIMARY KEY (`categoryID`),
  KEY `subID` (`subID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryID`, `subID`, `category`) VALUES
(1, 1, 'breakfast'),
(2, 1, 'fast_food'),
(3, 1, 'desert'),
(4, 2, 'non-fasting'),
(5, 2, 'fasting'),
(6, 3, 'soda'),
(7, 3, 'juice'),
(8, 3, 'water'),
(9, 4, 'wine'),
(10, 4, 'spirits'),
(11, 4, 'beer'),
(12, 5, 'homecare'),
(13, 5, 'kitchenAppliance'),
(14, 5, 'washers&Dryers'),
(15, 6, 'pc&desktop'),
(16, 6, 'cellphone&tablet'),
(17, 6, 'mobile&computerAccessories');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `custID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(30) NOT NULL,
  `middleName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `city` varchar(50) NOT NULL,
  `subcity` varchar(30) NOT NULL,
  `woreda` int(11) NOT NULL,
  `kebele` int(11) NOT NULL,
  `phoneNum` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`custID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `main_category`
--

CREATE TABLE IF NOT EXISTS `main_category` (
  `mainID` int(11) NOT NULL AUTO_INCREMENT,
  `mainCategory` varchar(30) NOT NULL,
  PRIMARY KEY (`mainID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `main_category`
--

INSERT INTO `main_category` (`mainID`, `mainCategory`) VALUES
(1, 'food'),
(2, 'beverage'),
(3, 'beauty'),
(4, 'sanitational'),
(5, 'electronics'),
(6, 'furniture'),
(7, 'cloth');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `orderID` int(11) NOT NULL AUTO_INCREMENT,
  `custID` int(11) NOT NULL,
  `subTotal` float NOT NULL,
  `tax` float NOT NULL,
  `delivery` float NOT NULL,
  `total` float NOT NULL,
  `createdAt` datetime NOT NULL,
  PRIMARY KEY (`orderID`),
  KEY `custID` (`custID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `prodID` int(11) NOT NULL AUTO_INCREMENT,
  `productName` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `price` float NOT NULL,
  `typeID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `img_src` varchar(30) NOT NULL,
  PRIMARY KEY (`prodID`),
  KEY `type` (`typeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=91 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prodID`, `productName`, `description`, `price`, `typeID`, `quantity`, `img_src`) VALUES
(1, 'Omelette Croissant', 'Croissant with omelette and cheese with extra sausage', 100, 1, 50, 'IMG_6908.jpg'),
(2, 'Special Ful', 'Ful with fried egg, tomato sauce, tomato, onion, chilli, yogurt with 2 breads', 85, 1, 50, 'IMG_6906.jpg'),
(3, 'Special Chechebsa', 'Chechebsa with egg, yogurt and honey', 110, 1, 30, 'IMG_6902.jpg'),
(4, 'Tuna Toast', 'Roasted toast with special tuna fill and ketchup as a sauce', 146, 1, 30, 'IMG_6901.jpg'),
(5, 'Waffle Chicken Club', 'Waffle with chicken fill, strawberry as a top and a seasoned boiled potatto ', 170, 1, 40, 'IMG_6895.jpg'),
(6, 'Waffle', 'Waffle with strawberry and banana', 200, 1, 60, 'IMG_6890.jpg'),
(7, 'Kitfo Sandwich', 'Kitfo Sandwich with aybey aside', 175, 2, 40, 'IMG_6865.jpg'),
(8, 'Special Pizza', 'Pizza with tuna and boiled egg at top', 300, 2, 25, 'IMG_6866.jpg'),
(9, 'Special Shawarma', 'Special Shawarma with french fries and sauce a side', 240, 2, 35, 'IMG_6868.jpg'),
(10, 'Chicken Pizza', 'Chicken Pizza and some chilli on top', 350, 2, 15, 'IMG_6867.jpg'),
(11, 'Double Burger', 'Double and 3x3(Triple) burger with some french fries', 335, 2, 38, 'IMG_6878.jpg'),
(12, 'Lasagna ', 'Fresh Lasagna with extra mazorella cheese ', 255, 2, 30, 'IMG_6870.jpg'),
(13, 'Gomen Kitfo Sandwich', 'Gomen Kitfo Sandwich with a special sauce', 130, 2, 35, 'IMG_6877.jpg'),
(14, 'Ertib', 'semi-fried potato with chili, onion and tomato sauce', 50, 2, 60, 'IMG_6879.jpg'),
(15, 'Chicken Wrap', 'Chicken wrap with grilled vegetable and Iced lettuce + chili sauce  ', 245, 2, 40, 'IMG_6874.jpg'),
(16, 'Chocolate mousse', 'Chocolate mousse with chocolate and cream +strawberry on top', 130, 3, 20, 'IMG_6896.jpg'),
(17, 'Nutella crepes', 'Nutella crepes with starwberry and banana + distilled cream on it', 200, 3, 20, 'IMG_6897.jpg'),
(18, 'Ice Cream', 'Ice Cream with m&ms, kisses and 2 biscuit chocolate ', 195, 3, 25, 'IMG_6898.jpg'),
(19, 'Cheese cake', 'Cheese cake with strawberry on top', 140, 3, 15, 'IMG_6900.jpg'),
(20, 'Oreo Pancake', 'Oreo Pancake with chocolate syrup', 165, 3, 15, 'IMG_6899.jpg'),
(21, 'Concord Cake', 'Concord Cake made with nutella chocolate and whipped cream', 225, 3, 10, 'IMG_6903.jpg'),
(22, 'White and Dark chocolate', 'White and Dark chocolate with white whipped cream on top of it', 225, 3, 8, 'IMG_6904.jpg'),
(23, 'Brownie', 'Brownie with mocha ice cream on top of it', 120, 3, 10, 'IMG_6910.jpg'),
(24, 'Special Combo', 'qurt sega, bacon beef, kitfo, gomen, aybey, suf firfir tibs, tera sega', 1400, 4, 40, 'IMG_6938.jpg'),
(25, 'Doro wot', 'Doro wot with boiled egg + injera', 500, 4, 30, 'IMG_6944.jpg'),
(26, 'Sega wot', 'Sega wot with a fresh baked injera', 650, 4, 35, 'IMG_6945.jpg'),
(27, 'Kitfo', 'a red raw meat with qebe + injera, ayebe and gomen as side dishes', 750, 4, 30, 'IMG_6946.jpg'),
(28, 'Kitfo gomen', 'Kitfo gomen with qebe', 300, 4, 50, 'IMG_6947.jpg'),
(29, 'Quanta Firfir', 'Firfir made with dried beef and boiled egg', 150, 4, 20, 'IMG_6950.jpg'),
(30, 'Awaze Tibs', 'made with tender lamb with awaze(red wine) sauce', 450, 4, 17, 'IMG_6954.jpg'),
(31, 'Alicha wot', 'made with beef, chili chops and some spices', 190, 4, 15, 'IMG_6956.jpg'),
(32, 'Tibs Firfir', 'made with meat and firfir + chops of chili', 130, 4, 10, 'IMG_6958.jpg'),
(33, 'Beyeynet', 'contains pasta, ayebe, egg, shiro, tibs and salad', 450, 4, 22, 'IMG_6943.jpg'),
(34, 'Tibs', 'Tibs with carrot and chili', 250, 4, 27, 'IMG_6934.jpg'),
(35, 'Shiro', 'a special type of food made with beans and berbere', 160, 5, 50, 'IMG_6961.jpg'),
(36, 'Beyeynet', 'contains misr wot, alecha kik, shiro, salad, gomen, wot', 200, 5, 30, 'IMG_6937.jpg'),
(37, 'Firfir', 'normal non-fasting firfir ', 50, 5, 100, 'IMG_6959.jpg'),
(38, 'misr wot', 'made with lentils and tomato sauce + berbere', 70, 5, 25, 'IMG_6964.jpg'),
(39, 'Alicha kik', 'made up with lentils and special spices', 70, 5, 40, 'IMG_6965.jpg'),
(40, 'Gomen', 'vegetable with some injera', 80, 5, 16, 'IMG_6962.jpg'),
(41, 'Wot Beyeynet', 'contains alicha kik, misr wot, gomen, salad and fasolia', 150, 5, 15, 'IMG_6967.jpg'),
(42, 'Fasolia', 'beans with carrot and onions ', 90, 5, 8, 'IMG_6972.jpg'),
(43, 'Atakilt wot', 'made up with cabbage, potato &carrot ', 45, 5, 30, 'IMG_6966.jpg'),
(44, 'Coca Cola', 'Coca Cola soda drink 591ml', 40, 6, 30, 'IMG_6545.jpg'),
(45, 'Pepsi', 'Pepsi 500ml', 50, 6, 50, 'IMG_6547.jpg'),
(46, 'Sprite', 'Sprite 500ml', 40, 6, 25, 'IMG_6548.png'),
(47, 'Mirinda', 'Mirinda 360ml', 35, 6, 20, 'IMG_6550.jpg'),
(48, 'Fanta Orange', 'Fanta with orange flavor 360ml', 45, 6, 30, 'IMG_6551.jpg'),
(49, 'Predator', 'Predator energy drink 360ml', 70, 6, 40, 'IMG_6807.png'),
(50, 'Redbull', 'Redbull energy drink 300ml', 130, 6, 10, 'IMG_6559.jpg'),
(51, 'Bison', 'Bison energy drink 300ml', 170, 6, 15, 'IMG_6790.jpg'),
(52, 'Code Red', 'Code Red energy drink 300ml', 165, 6, 24, 'IMG_6788.jpg'),
(53, 'Malta Guinness', 'Malt(Non Alcoholic) drink 250ml', 40, 6, 30, 'IMG_6554.jpg'),
(54, 'Fain Guava Juice', 'made with concentrated Guava nectar 1L ', 250, 7, 20, 'IMG_6558.jpg'),
(55, 'Dimes Apple Juice', 'organic Apple dimes juice 1L', 250, 7, 10, 'IMG_6556.jpg'),
(56, 'Fain Apple Juice', 'Fain Apple natural juice 1L', 230, 7, 15, 'IMG_6555.jpg'),
(57, 'Pran Mango Juice', 'Mango juice 100% natural 1L', 270, 7, 30, 'IMG_6794.jpg'),
(58, 'Fontana Red Grape Juice', 'Freshning red grape juice 1L', 300, 7, 18, 'IMG_6800.jpg'),
(59, 'Simply Orange juice', 'pasteurized orange juice 1.53L', 310, 7, 10, 'IMG_6795.jpg'),
(60, 'Tropicana punch juice', 'zero sugar punch juice 1.53L', 360, 7, 20, 'IMG_6796.jpg'),
(61, 'Ocean Spray RubyRed juice', 'grapefruit juice, no sugar added 1.77L', 400, 7, 13, 'IMG_6801.jpg'),
(62, 'Aquaddis water', 'chemical free water 500ml', 19, 8, 100, 'IMG_6557.jpg'),
(63, 'Unique water', 'natural water form highland of ethiopia 2L', 35, 8, 20, 'IMG_6806.jpg'),
(64, 'Apple Ambo water', 'sparkling water with apple flavor 500ml', 40, 8, 20, 'IMG_6818.jpg'),
(65, 'Gold water', 'natural water 300ml', 20, 8, 90, 'IMG_6811.jpg'),
(66, 'Ambo water', 'sparkling water 500ml', 35, 8, 60, 'IMG_6553.jpg'),
(67, 'Lemon Ambo water', 'sparkling water with lemon flavor 500ml', 40, 8, 50, 'IMG_6552.jpg'),
(68, 'Rift Valley Cabernet Sauvignon', 'dry red wine 2017 750L', 340, 9, 20, 'IMG_6847.jpg'),
(69, 'Acacia rose wine', 'medium sweet rose wine 750mL', 480, 9, 20, 'IMG_6851.jpg'),
(70, 'La Verde ', 'Domaine De La Verde 2020 1L', 990, 9, 10, 'IMG_6864.jpg'),
(71, 'Rift Valley Malbec', 'Dry rose wine 750ml', 540, 9, 15, 'IMG_6849.jpg'),
(72, 'La Casetta wine ', 'Domini Veneti La Casetta Red wine 1L', 1200, 9, 17, 'IMG_6863.jpg'),
(73, 'Reciprocity Cabernet Sauvignon', 'Cabernet Sauvignon from Highlands of California 750ml', 1500, 9, 15, 'IMG_6859.jpg'),
(74, 'Acacia red wine', 'dry red wine made from Highland of Ethiopia 750ml', 530, 9, 10, 'IMG_6562.jpg'),
(75, 'Absolut vodka', 'Absolut vodka from the village of Ahus, Sweden 750mL', 995, 10, 10, 'IMG_6566.jpg'),
(76, 'Smirnoff vodka', 'Smirnoff vodka since 1864 USA 40% alcohol 750mL', 1200, 10, 15, 'IMG_6567.jpg'),
(77, 'Red Label whisky', 'Johnnie walker whisky USA since 1820 750 mL', 1500, 10, 10, 'IMG_6568.jpg'),
(78, 'Double Black', 'John walker whisky USA 750mL ', 1000, 10, 20, 'IMG_6569.jpg'),
(79, 'Casamigos tequila ', 'Casamigos tequila 100% Agave Azul from Jalisco, Mexico 750mL', 850, 10, 20, 'IMG_6834.jpg'),
(80, 'Adictivo tequila', 'Adictivo tequila de Aqave 40% alcohol 750mL', 790, 10, 17, 'IMG_6836.jpg'),
(81, 'Hendrick''s gin', 'Hendrick''s gin 44% alcohol from scotland 750mL', 1600, 10, 12, 'IMG_6838.jpg'),
(82, 'Tanqueray gin', 'London dry gin 47.7% alcohol  750mL', 1700, 10, 12, 'IMG_6840.jpg'),
(83, 'Anbessa beer', 'nictorious beer premium lager 330mL ', 70, 11, 100, 'IMG_6571.jpg'),
(84, 'Heineken beer', 'Heineken lager beer premium quality 330mL', 130, 11, 20, 'IMG_6570.png'),
(85, 'Habesha beer', 'Habesha beer gold 330mL', 90, 11, 13, 'IMG_6842.jpg'),
(86, 'Bedele beer', 'Bedele special beer from ethiopia 330mL', 110, 11, 14, 'IMG_6843.jpg'),
(87, 'Carlsberg beer', 'elephant beer premium strong 330mL', 220, 11, 16, 'IMG_6857.jpg'),
(88, 'kingfisher', 'premium lager beer 355mL', 170, 11, 15, 'IMG_6853.jpg'),
(89, 'St. George Beer', 'premium lager beer 330mL', 165, 11, 24, 'IMG_6845.jpg'),
(90, 'Strong Kingfisher beer', 'strong premium beer 330mL', 169, 11, 30, 'IMG_6855.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE IF NOT EXISTS `sub_category` (
  `subID` int(11) NOT NULL AUTO_INCREMENT,
  `mainID` int(11) NOT NULL,
  `subCategory` varchar(30) NOT NULL,
  PRIMARY KEY (`subID`),
  KEY `mainID` (`mainID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='re' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`subID`, `mainID`, `subCategory`) VALUES
(1, 1, 'modern'),
(2, 1, 'cultural'),
(3, 2, 'soft_drinks'),
(4, 2, 'alcohol'),
(5, 3, 'male'),
(6, 3, 'female'),
(7, 4, 'sanitational'),
(8, 5, 'home_appliance'),
(9, 5, 'computer_accessories\n'),
(10, 6, 'home'),
(11, 6, 'office'),
(12, 7, 'modern_cloth'),
(13, 7, 'traditional_cloth');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_item`
--
ALTER TABLE `cart_item`
  ADD CONSTRAINT `orderID_fr` FOREIGN KEY (`orderID`) REFERENCES `order` (`orderID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `prodID_fr` FOREIGN KEY (`prodID`) REFERENCES `product` (`prodID`) ON UPDATE CASCADE;

--
-- Constraints for table `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `subID_fr` FOREIGN KEY (`subID`) REFERENCES `sub_category` (`subID`);

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `custID_fr` FOREIGN KEY (`custID`) REFERENCES `customer` (`custID`) ON UPDATE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `type_fr` FOREIGN KEY (`typeID`) REFERENCES `category` (`categoryID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD CONSTRAINT `mainID_fr` FOREIGN KEY (`mainID`) REFERENCES `main_category` (`mainID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
